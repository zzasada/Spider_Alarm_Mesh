#Fota

<!-- arm-none-eabi-objcopy -I ihex -O binary fota_receiver-nrf52840-os.hex 0.bin -->
arm-none-eabi-objcopy -I ihex -O binary fota_receiver-nrf52840ble-os.hex 0.bin