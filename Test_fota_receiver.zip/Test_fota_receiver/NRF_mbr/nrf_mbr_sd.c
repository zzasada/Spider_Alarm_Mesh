__attribute__((section(".nrf_mbr_sd")))
int nrf_mbr_sd[0];